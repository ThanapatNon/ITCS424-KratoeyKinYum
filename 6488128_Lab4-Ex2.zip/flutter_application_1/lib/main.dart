import 'package:flutter/material.dart';

class ExplorePage extends StatelessWidget {
  const ExplorePage({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          width: double.maxFinite,
          decoration: AppDecoration.fillWhiteA,
          child: Column(
            children: [
              _buildSeventeen(context),
              SizedBox(height: 25.v),
              SizedBox(
                height: 715.v,
                width: 425.h,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    _buildNineteen(context),
                    _buildViewHierarchy(context),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildSeventeen(BuildContext context) {
    return SizedBox(
      height: 192.v,
      width: double.maxFinite,
      child: Stack(
        alignment: Alignment.center,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgRectangle30,
            height: 156.v,
            width: 410.h,
            alignment: Alignment.topLeft,
          ),
          Align(
            alignment: Alignment.center,
            child: SizedBox(
              height: 192.v,
              width: double.maxFinite,
              child: Stack(
                alignment: Alignment.bottomLeft,
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgPic,
                    height: 192.v,
                    width: 430.h,
                    alignment: Alignment.center,
                  ),
                  Align(
                    alignment: Alignment.bottomLeft,
                    child: Padding(
                      padding: EdgeInsets.only(
                        left: 17.h,
                        bottom: 2.v,
                      ),
                      child: Text(
                        "Explore",
                        style: theme.textTheme.displayMedium,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Section Widget
  Widget _buildNineteen(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Container(
        margin: EdgeInsets.fromLTRB(18.h, 540.v, 27.h, 11.v),
        padding: EdgeInsets.all(1.h),
        decoration: AppDecoration.fillBlack.copyWith(
          borderRadius: BorderRadiusStyle.roundedBorder15,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Padding(
              padding: EdgeInsets.only(
                left: 23.h,
                top: 100.v,
                bottom: 10.v,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "10.00-21.00",
                    style: theme.textTheme.titleLarge,
                  ),
                  Text(
                    "OPEN",
                    style: theme.textTheme.headlineSmall,
                  ),
                ],
              ),
            ),
            CustomImageView(
              imagePath: ImageConstant.imgImage4,
              height: 162.v,
              width: 210.h,
              radius: BorderRadius.circular(
                15.h,
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildViewHierarchy(BuildContext context) {
    return Align(
      alignment: Alignment.center,
      child: ListView.separated(
        physics: NeverScrollableScrollPhysics(),
        shrinkWrap: true,
        separatorBuilder: (
          context,
          index,
        ) {
          return SizedBox(
            height: 1.v,
          );
        },
        itemCount: 6,
        itemBuilder: (context, index) {
          return ViewhierarchyItemWidget();
        },
      ),
    );
  }
}

class AppDecoration {
}
