import 'package:flutter/material.dart';
import 'package:untitled4/Home.dart';
import 'package:untitled4/Location.dart';
import 'package:untitled4/Search.dart';
import 'package:untitled4/SignIn.dart';
import 'Explore.dart';

class DashboardPage extends StatelessWidget {
  const DashboardPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Dashboard'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Profile logo
          CircleAvatar(
            radius: 50,
            backgroundImage: NetworkImage('https://images.rawpixel.com/image_png_800/cHJpdmF0ZS9sci9pbWFnZXMvd2Vic2l0ZS8yMDIzLTAxL3JtNjA5LXNvbGlkaWNvbi13LTAwMi1wLnBuZw.png'),
          ),
          SizedBox(height: 20),
          // Edit Profile and View Points buttons in the same row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              ElevatedButton(
                onPressed: () {
                  // Add functionality to edit profile
                },
                child: Text('Edit Profile'),
              ),
              ElevatedButton(
                onPressed: () {
                  // Add functionality to view points
                },
                child: Text('View Points'),
              ),
            ],
          ),
          Spacer(), // Add space between buttons and sign out button
          // Sign Out button
          ElevatedButton(
            onPressed: () {
              // Navigate back to sign in page
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => SignInPage()), // Replace SignInPage with your sign in page
              );
            },
            child: Text('Sign Out'),
          ),
        ],
      ),
      bottomNavigationBar: buildBottomNavigationBar(context, 4), // Pass the index of "Dashboard" item
    );
  }
}

BottomNavigationBar buildBottomNavigationBar(BuildContext context, int selectedIndex) {
  return BottomNavigationBar(
    backgroundColor: Colors.black,
    selectedItemColor: Color.fromARGB(255, 2, 69, 177), // Changed selected item color to white
    unselectedItemColor: Colors.black, // Changed unselected item color to white
    currentIndex: selectedIndex,
    onTap: (int index) {
      switch (index) {
        case 0: // Home
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => HomePage()),
          );
          break;
        case 1: // Search
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => SearchPage()),
          );
          break;
        case 2: // Explore
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => ExploreScreen()),
          );
          break;
        case 3: // Location
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => LocationPage()),
          );
          break;
        case 4: // Dashboard
          // Stay on Dashboard page
          break;
      }
    },
    items: [
      BottomNavigationBarItem(
        icon: Icon(Icons.home),
        label: 'Home',
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.search),
        label: 'Explore',
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.restaurant_menu),
        label: 'Food List',
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.location_on),
        label: 'Location',
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.dashboard),
        label: 'Dashboard',
      ),
    ],
  );
}
