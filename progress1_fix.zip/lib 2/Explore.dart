import 'package:flutter/material.dart';
import 'package:untitled4/Home.dart';
import 'package:untitled4/Location.dart';

import 'Dashboard.dart';
import 'Search.dart';

class ExploreScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Explore'),
      ),
      body: ListView.builder(
        itemCount: restaurants.length,
        itemBuilder: (BuildContext context, int index) {
          return ListTile(
            title: Text(restaurants[index]),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => RestaurantDetailsScreen(
                    restaurantName: restaurants[index],
                    selectedIndex: 2, // Index of "Food List" item
                  ),
                ),
              );
            },
          );
        },
      ),
      bottomNavigationBar: buildBottomNavigationBar(context, 2), // Pass the index of "Search" item
    );
  }
}

class RestaurantDetailsScreen extends StatelessWidget {
  final String restaurantName;
  final int selectedIndex;

  RestaurantDetailsScreen({required this.restaurantName, required this.selectedIndex});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(restaurantName),
      ),
      body: Center(
        child: Text('Details of $restaurantName'),
      ),
      bottomNavigationBar: buildBottomNavigationBar(context, selectedIndex),
    );
  }
}

List<String> restaurants = [
  'Restaurant 1',
  'Restaurant 2',
  'Restaurant 3',
  'Restaurant 4',
  'Restaurant 5',
];

BottomNavigationBar buildBottomNavigationBar(BuildContext context, int selectedIndex) {
  return BottomNavigationBar(
    backgroundColor: Colors.black,
    selectedItemColor: Color.fromARGB(255, 2, 69, 177), // Changed selected item color to white
    unselectedItemColor: Colors.black, // Changed unselected item color to white
    currentIndex: selectedIndex,
    onTap: (int index) {
      switch (index) {
        case 0: // Home
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => HomePage()), // Navigate to ExploreScreen
          );
          break;
       case 1: // Search
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => SearchPage()),
          );
          break;
        case 2:
          
          break;
        case 3: // Location
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => LocationPage()),
          );
          break;
        case 4: // Dashboard
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => DashboardPage()),
          );
          break;
      }
    },
    items: [
      BottomNavigationBarItem(
        icon: Icon(Icons.home),
        label: 'Home',
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.search),
        label: 'Search',
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.restaurant_menu),
        label: 'Food List',
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.location_on),
        label: 'Location',
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.dashboard),
        label: 'Dashboard',
      ),
    ],
  );
}
