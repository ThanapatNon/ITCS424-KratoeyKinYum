import 'package:flutter/material.dart';
import 'package:untitled4/Dashboard.dart';
import 'Explore.dart';
import 'Location.dart';
import 'Search.dart'; // Import the Explore.dart file

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Home'),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Image.network(
            'https://cdn.discordapp.com/attachments/619409323440865282/1212780511404105809/image.png?ex=65f314de&is=65e09fde&hm=5d93b0275db66a5dda9ff37f68e0ffa2ef24816bece18b52e93bc7e949239b75&',
            fit: BoxFit.cover,
          ),
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                TabButton(text: 'Fine Dining'),
                TabButton(text: 'Buffet'),
                TabButton(text: 'All You Can Eat'),
              ],
            ),
          ),
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              'Welcome',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(height: 20),
          Image.network(
            'https://www.unileverfoodsolutions.co.th/dam/global-ufs/mcos/SEA/calcmenu/recipes/TH-recipes/pasta-dishes/%E0%B8%A2%E0%B8%B3%E0%B8%82%E0%B8%99%E0%B8%A1%E0%B8%88%E0%B8%B5%E0%B8%99/%E0%B8%A2%E0%B8%B3%E0%B8%82%E0%B8%99%E0%B8%A1%E0%B8%88%E0%B8%B5%E0%B8%99_header.jpg',
            width: 200, // Adjust width as needed
            height: 200, // Adjust height as needed
          ),
          // Add other content here as needed
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.black,
        selectedItemColor: Color.fromARGB(255, 2, 69, 177), // Changed selected item color to white
        unselectedItemColor: Colors.black, // Changed unselected item color to white
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.search),
            label: 'Search',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.restaurant_menu),
            label: 'Food List',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.location_on),
            label: 'Location',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.dashboard),
            label: 'Dashboard',
          ),
        ],
         onTap: (int index) {
          switch (index) {
            case 0: // Home
              break;
           case 1: // Search
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => SearchPage()),
          );
          break;
            case 2: // Food List
                 Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ExploreScreen()), // Navigate to ExploreScreen
              );
              break;
            case 3: // Location
              Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => LocationPage()),
          );
              break;
            case 4: // Dashboard
              Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => DashboardPage()),
          );
              break;
          }
         },
      ),
    );
  }
}

class TabButton extends StatelessWidget {
  final String text;

  const TabButton({Key? key, required this.text}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: () {
        // Add functionality for each tab button
      },
      child: Text(text),
    );
  }
}
