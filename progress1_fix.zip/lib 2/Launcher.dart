import 'package:flutter/material.dart';
import 'signin.dart'; // Import the file where you want to navigate

void main() {
  runApp(LauncherApp());
}

class LauncherApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Launcher App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: LauncherScreen(),
    );
  }
}

class LauncherScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('HIWKHAO'), // Title "HIWKHAO"
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image.network(
              'https://cdn.discordapp.com/attachments/832679570674286612/1213080683405115412/4b762046546be7d87aa4d4ebb5494c35.png?ex=65f42c6c&is=65e1b76c&hm=d1992d6da6d7a479842bc0fab256dd431a2db8aae9d7890c66308b029182c9b0',
              width: 200, // Adjust width as needed
              height: 200, // Adjust height as needed
            ),
            SizedBox(height: 20), // Add some spacing between the image and button
            ElevatedButton(
              onPressed: () {
                // Navigate to SignInScreen when button is pressed
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => SignInPage()),
                );
              },
              child: Text('Start'),
            ),
          ],
        ),
      ),
    );
  }
}
