import 'package:flutter/material.dart';
import 'package:untitled4/Dashboard.dart';
import 'package:untitled4/Explore.dart';
import 'package:untitled4/Home.dart';

import 'Search.dart';




class LocationPage extends StatelessWidget {
  const LocationPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Location'),
      ),
      body: Column(
        children: [
          Image.network(
            'https://cdn.discordapp.com/attachments/832679570674286612/1213188720161980447/9631dfcad3702595fe83f7e784b8a88b.png?ex=65f4910a&is=65e21c0a&hm=252eea05d2b050111785d6a6c55246f4451445f2426aba177636a751255ae052',
            fit: BoxFit.cover,
          ),
          SizedBox(height: 20),
          Center(
            child: Text(
              'Location Content',
              style: TextStyle(fontSize: 24),
            ),
          ),
        ],
      ),
      bottomNavigationBar: buildBottomNavigationBar(context, 3), // Pass the index of "Location" item
    );
  }
}

BottomNavigationBar buildBottomNavigationBar(BuildContext context, int selectedIndex) {
  return BottomNavigationBar(
    backgroundColor: Colors.black,
    selectedItemColor: Color.fromARGB(255, 2, 69, 177), // Changed selected item color to white
    unselectedItemColor: Colors.black, // Changed unselected item color to white
    currentIndex: selectedIndex,
    onTap: (int index) {
      switch (index) {
        case 0: // Home
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => HomePage()),
          );
          break;
       case 1: // Search
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => SearchPage()),
          );
          break;
        case 2: // Food List
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => ExploreScreen()),
          );
          break;
        case 3: // Location
          // Stay on Location page
          break;
        case 4: // Dashboard
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => DashboardPage()),
          );
          break;
      }
    },
    items: [
      BottomNavigationBarItem(
        icon: Icon(Icons.home),
        label: 'Home',
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.search),
        label: 'Explore',
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.restaurant_menu),
        label: 'Food List',
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.location_on),
        label: 'Location',
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.dashboard),
        label: 'Dashboard',
      ),
    ],
  );
}
