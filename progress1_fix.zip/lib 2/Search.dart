import 'package:flutter/material.dart';
import 'package:untitled4/Dashboard.dart';
import 'package:untitled4/Explore.dart';
import 'package:untitled4/Home.dart';
import 'package:untitled4/Location.dart';


class SearchPage extends StatefulWidget {
  const SearchPage({Key? key}) : super(key: key);

  @override
  _SearchPageState createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  String _searchQuery = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Search'),
        actions: [
          IconButton(
            icon: Icon(Icons.search),
            onPressed: () {
              // Perform search based on _searchQuery
              // For now, let's just print the search query
              print('Search query: $_searchQuery');
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search for restaurants...',
              ),
              onChanged: (value) {
                setState(() {
                  _searchQuery = value;
                });
              },
            ),
          ),
          // You can display search results here based on _searchQuery
          // For now, let's just display a placeholder text
          Expanded(
            child: Center(
              child: Text(
                _searchQuery.isEmpty ? 'Start typing to search' : 'Search results for: $_searchQuery',
                style: TextStyle(fontSize: 18),
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: buildBottomNavigationBar(context, 1), // Pass the index of "Search" item
    );
  }
}

BottomNavigationBar buildBottomNavigationBar(BuildContext context, int selectedIndex) {
  return BottomNavigationBar(
    backgroundColor: Colors.black,
    selectedItemColor: Color.fromARGB(255, 2, 69, 177), // Changed selected item color to white
    unselectedItemColor: Colors.black, // Changed unselected item color to white
    currentIndex: selectedIndex,
    onTap: (int index) {
      switch (index) {
        case 0: // Home
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => HomePage()),
          );
          break;
        case 1: // Explore
          break;
        case 2: // Food List
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => ExploreScreen()),
          );
          break;
        case 3: // Location
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => LocationPage()),
          );
          break;
        case 4: // Dashboard
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => DashboardPage()),
          );
          break;
      }
    },
    items: [
      BottomNavigationBarItem(
        icon: Icon(Icons.home),
        label: 'Home',
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.search),
        label: 'Explore',
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.restaurant_menu),
        label: 'Food List',
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.location_on),
        label: 'Location',
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.dashboard),
        label: 'Dashboard',
      ),
    ],
  );
}
