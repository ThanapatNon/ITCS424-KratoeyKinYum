import 'package:flutter/material.dart';

void main() {
  runApp(const FigmaToCodeApp());
}

class FigmaToCodeApp extends StatelessWidget {
  const FigmaToCodeApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color.fromARGB(255, 18, 32, 47),
      ),
      home: Scaffold(
        body: ListView(
          children: const [
            Location(),
          ],
        ),
      ),
    );
  }
}

class Location extends StatelessWidget {
  const Location({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 430,
          height: 932,
          clipBehavior: Clip.antiAlias,
          decoration: ShapeDecoration(
            color: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(30),
            ),
          ),
          child: Stack(
            children: [
              Positioned(
                left: -78,
                top: 372,
                child: Container(
                  width: 509,
                  height: 714,
                  child: Stack(
                    children: [
                      Positioned(
                        left: 67,
                        top: 467,
                        child: Container(
                          width: 442,
                          height: 94,
                          decoration:
                              BoxDecoration(color: const Color(0xFFFFF5F5)),
                        ),
                      ),
                      Positioned(
                        left: 116,
                        top: 492,
                        child: Container(
                          width: 355.37,
                          height: 32.36,
                          child: Stack(
                            children: [
                              // Add your widgets here
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                left: -57,
                top: 0,
                child: Container(
                  width: 518,
                  height: 839,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image:
                          NetworkImage("https://via.placeholder.com/518x839"),
                      fit: BoxFit.fill,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 9,
                top: 46,
                child: Container(
                  width: 412,
                  height: 164,
                  decoration: ShapeDecoration(
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    shadows: [
                      BoxShadow(
                        color: const Color(0x3F000000),
                        blurRadius: 4,
                        offset: const Offset(0, 4),
                        spreadRadius: 0,
                      )
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 24,
                top: 159,
                child: Container(
                  width: 20.62,
                  height: 27,
                  child: Stack(
                    children: [
                      // Add your widgets here
                    ],
                  ),
                ),
              ),
              Positioned(
                left: 297,
                top: 54,
                child: SizedBox(
                  width: 159,
                  height: 39,
                  child: Text(
                    'Location',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 30,
                      fontFamily: 'Sofia Sans',
                      fontWeight: FontWeight.w700,
                      height: 0,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 30,
                top: 94,
                child: Container(
                  width: 372,
                  height: 47,
                  decoration: ShapeDecoration(
                    color: const Color(0xFFF6E3E3),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 72,
                top: 107,
                child: SizedBox(
                  width: 302,
                  height: 22,
                  child: Text(
                    'Search your location',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 17,
                      fontFamily: 'Sofia Sans',
                      fontWeight: FontWeight.w400,
                      height: 0,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 53,
                top: 163,
                child: SizedBox(
                  width: 356,
                  height: 26,
                  child: Text(
                    'Ratchaprasong, Bangkok',
                    style: TextStyle(
                      color: const Color(0xFF14319A),
                      fontSize: 17,
                      fontFamily: 'Sofia Sans',
                      fontWeight: FontWeight.w400,
                      height: 0,
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 338,
                top: 160,
                child: SizedBox(
                  width: 92,
                  height: 34,
                  child: Text(
                    'Explore',
                    style: TextStyle(
                      color: const Color(0xFF0D6CDB),
                      fontSize: 20,
                      fontFamily: 'Sofia Sans',
                      fontWeight: FontWeight.w400,
                      height: 0,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
