#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=C:\Users\Thanapat Nonpassopon\flutter_windows_3.16.5-stable\flutter"
export "FLUTTER_APPLICATION_PATH=D:\My Personal Files\Works\MUICT Works\MUICT - Year 3\Y3 - Semester 2\ITCS424 Wireless and Mobile Computing\Projects\6488128_PJ_w5-3\flutter_application_page1"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.0"
export "FLUTTER_BUILD_NUMBER=1"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
